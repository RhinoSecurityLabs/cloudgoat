def lambda_handler(event, context):
    import boto3
    client = boto3.client('iam')
    users = client.list_users()
    return users

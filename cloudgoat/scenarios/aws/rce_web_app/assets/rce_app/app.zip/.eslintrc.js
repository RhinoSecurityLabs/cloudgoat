module.exports = {
  extends: 'airbnb-base',
  parser: 'babel-eslint',
  plugins: ['babel'],
  rules: {
    'no-plusplus': 0
  },
  globals: {},
};

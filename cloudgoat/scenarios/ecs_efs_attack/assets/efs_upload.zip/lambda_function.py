import json
import os 

def lambda_handler(event, context):
    
    text = event['text']
    fname = event['fname']
    
    with open(f'/mnt/admin/{fname}', 'w') as f:
        f.write(text)
        f.close()
    
    return {
        'statusCode': 200,
        'body': json.dumps('File written to efs')
    }

import psycopg2

# PostgreSQL 연결 정보 설정
conn = psycopg2.connect(
    dbname='data',
    user='postgres',
    password='bob12cgv',
    host='database-1.cxs3fy07fbaz.us-east-1.rds.amazonaws.com',
    port=5432
)

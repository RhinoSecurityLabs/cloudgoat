import boto3

# AWS S3 설정
AWS_ACCESS_KEY_ID = 'AKIASQVYKFJ5Q7BGJ7PW'
AWS_SECRET_ACCESS_KEY = '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'
AWS_REGION = 'us-east-1'
AWS_BUCKET_NAME = 'test-glue-scenario'

s3 = boto3.client('s3')